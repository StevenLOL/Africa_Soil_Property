int CheckCatRule(Node *n,int VarI, int *cats);
int CheckOrdRule(Node *n, int VarI, int left, int right);
int CheckRule(Node *n,int VarI);
int AreRulesEqual(Rule *r1,Rule *r2);
double SwapRule(Node *top,int *Done);



